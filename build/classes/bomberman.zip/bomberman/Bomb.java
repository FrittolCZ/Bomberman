/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bomberman;

import java.util.ArrayList;

/**
 *
 * @author fanda
 */
class Bomb {

    private float timeToExplode = 2000;
    private float flamesTimer = 1000;

    private ArrayList<Brick> particles;

    private ArrayList<Brick> flames;

    private boolean dead = false;

    public Bomb(ArrayList<Brick> parts) {
        initParts(parts);
    }

    private void initParts(ArrayList<Brick> parts) {
        particles = new ArrayList<>();
        parts.stream().map((part) -> new Brick(part.getX(), part.getY())).forEachOrdered((bombPart) -> {
            particles.add(bombPart);
        });
    }

    public void setFlames(ArrayList<Brick> flames) {
        this.flames = flames;
    }

    public ArrayList<Brick> getFlames() {
        return flames;
    }

    public ArrayList<Brick> getParticles() {
        return particles;
    }

    /**
     *
     * @return - True pokud bomba již vybouchla
     */
    public boolean isDead() {
        return dead;
    }

    public void update(float delta) {

        if (timeToExplode <= 0) {
            particles.forEach((part) -> {
                part.deactive();
            });
            flames.forEach((flame) -> {
                flame.active();
            });
            if (this.flamesTimer <= 0) {
                dead = true; 
            } else {
                flamesTimer -= delta;
            }
        } else {
            this.timeToExplode -= delta;
        }
    }

}
