/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bomberman;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Duration;

/**
 *
 * @author fanda
 */
public class Bomberman extends Application {

    private static final int DELAY = 100;
    private static final int UNIT_SIZE = 12;
    private GamePane gamePane;
    private Timeline timeline;
    private final MyGameState game = new MyGameState();
    private Client client;
    private BorderPane root;
    private Button createBtn, connectBtn;
    private Scene menuScene, gameScene;
    private Stage primaryStage;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;

        gamePane = new GamePane(UNIT_SIZE, game);
        gameScene = new Scene(gamePane);
        gameScene.setOnKeyPressed(this::dispatchKeyEvents);

        createBtn = new Button("Založit hru");
        connectBtn = new Button("Připojit se");

        createBtn.setOnAction((ActionEvent e) -> {
            CreateGameDialog crs;
            try {
                client = new Client();
                crs = new CreateGameDialog(primaryStage, client);
                crs.centerOnScreen();
                crs.show();
            } catch (IOException ex) {
                Logger.getLogger(Bomberman.class.getName()).log(Level.SEVERE, null, ex);
            }
            //primaryStage.setScene(gameScene);
        });

        connectBtn.setOnAction((ActionEvent e) -> {
            // zobraz dialog připojení ke hře
        });

        timeline = new Timeline();
        KeyFrame updates = new KeyFrame(Duration.millis(DELAY), e -> {
            game.update(DELAY);
        }
        );
        timeline.getKeyFrames().add(updates);
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();

        GridPane menuPane = new GridPane();

        menuPane.setAlignment(Pos.CENTER);

        menuPane.setHgap(20);
        menuPane.setVgap(10);

        Text lbCaption = new Text("Bomberman");
        lbCaption.setFont(Font.font(35));

        menuPane.addRow(1, lbCaption);
        menuPane.addRow(2, createBtn);
        menuPane.addRow(3, connectBtn);

        GridPane.setHalignment(lbCaption, HPos.CENTER);
        GridPane.setHalignment(createBtn, HPos.CENTER);
        GridPane.setHalignment(connectBtn, HPos.CENTER);

        root = new BorderPane();

        root.setCenter(menuPane);

        menuScene = new Scene(root, 600, 800);
        primaryStage.setTitle("Bomberman");
        primaryStage.setScene(menuScene);
        primaryStage.show();

        primaryStage.setOnCloseRequest((WindowEvent we) -> {
            if (client.isServerOwner()) {
                client.stopServer();
            }
        });

    }

    private void dispatchKeyEvents(KeyEvent e) {
        switch (e.getCode()) {
            case LEFT:
                //pošli zprávu serveru
                //client.moveLeft();
                game.moveLeft();
                break;
            case RIGHT:
                game.moveRight();
                break;
            case DOWN:
                game.moveDown();
                break;
            case UP:
                game.moveUp();
                break;
            case SPACE:
                gamePane.drawBomb(game.placeBomb());
                break;
            case ESCAPE:
                primaryStage.setScene(menuScene);
                break;
            default:
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    /*private void createMenu(Stage primaryStage) {
        menu = new MenuBar();
        Menu gameMenu = new Menu("Hra");
        MenuItem create, connect;

        create = new MenuItem("Vytvořit");
        create.setOnAction((ActionEvent e) -> {
            CreateGameDialog crs;
            try {
                client = new Client();
                crs = new CreateGameDialog(primaryStage, client);
                crs.centerOnScreen();
                crs.show();
            } catch (IOException ex) {
                Logger.getLogger(Bomberman.class.getName()).log(Level.SEVERE, null, ex);
            }

        });
        connect = new MenuItem("Připojit");
        connect.setOnAction((ActionEvent e) -> {
            ConnectGameDialog crs;
            try {
                client = new Client();
                crs = new ConnectGameDialog(primaryStage, client);
                crs.centerOnScreen();
                crs.show();
            } catch (IOException ex) {
                Logger.getLogger(Bomberman.class.getName()).log(Level.SEVERE, null, ex);
            }

        });

        //create.setDisable(true);
        //connect.setDisable(true);
        gameMenu.getItems().addAll(create, connect);
        menu.getMenus().addAll(gameMenu);
    }*/
}
