/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bomberman;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;

/**
 *
 * @author fanda
 */
public class Client {

    private String username;

    private final int port = 4242;
    // nová hrací plocha
    private MyGameState game;

    private Socket socket;

    private ObjectInputStream sInput;
    private ObjectOutputStream sOutput;

    //jména připojených hráčů
    private ArrayList<String> playersConnected;

    private ListView players;

    private TextArea chatArea;

    private boolean logMsgs = true;

    private ListenFromServer listeningThread;
    
    private boolean serverOwner = false;

    public Client() {
        playersConnected = new ArrayList<>();
    }

    public void setName(String name) {
        this.username = name;
    }

    public boolean isServerOwner()
    {
        return serverOwner;
    }
    
    public void setServerOwner()
    {
        serverOwner = true;
    }
    
    public boolean start() {
        // try to connect to the server
        try {
            socket = new Socket("localhost", port);
        } // if it failed not much I can so
        catch (IOException ec) {
            System.out.println("Chyba připojení k serveru:" + ec);
            return false;
        }

        String msg = "Connection accepted " + socket.getInetAddress() + ":" + socket.getPort();
        System.out.println(msg);

        /* Creating both Data Stream */
        try {
            sInput = new ObjectInputStream(socket.getInputStream());
            sOutput = new ObjectOutputStream(socket.getOutputStream());

        } catch (IOException eIO) {
            System.out.println("Exception creating new Input/output Streams: " + eIO);
            return false;
        }

        // creates the Thread to listen from the server 
        listeningThread = new ListenFromServer();
        listeningThread.start();
        // Pošle serveru svoje jméno
        try {
            System.out.println(username);
            sOutput.writeObject(username);
        } catch (IOException eIO) {
            return false;
        }
        // success we inform the caller that it worked
        return true;
    }

    private void sendMessage(String msg) {
        try {
            sOutput.writeObject(msg);
        } catch (IOException e) {
            System.out.println("Exception writing to server: " + e);
        }
    }

    public void sendChatMsg(String msgText) {
        sendMessage("MSG " + username + " " + msgText);
    }

    public void stopServer() {

        sendMessage("STOP " + username);
        listeningThread.stopListening();
    }

    public void log(TextArea area, ListView players) {
        this.chatArea = area;
        this.players = players;
    }

    private void msgAct(String msg) {
        String[] parts = msg.split(" ");
        switch (parts[0]) {
            case "PLAYER_CONNECTED":
                players.getItems().add(parts[1]);
                break;
            case "MSG":
                chatArea.appendText(parts[1] + ": " + getMsgText(parts));
                break;
            default:
                break;
        }
    }

    private String getMsgText(String[] parts) {
        StringBuilder text = new StringBuilder();
        for (int i = 2; i < parts.length; i++) {
            text.append(parts[i]).append(" ");
        }
        text.append("\n");
        return text.toString();
    }

    class ListenFromServer extends Thread {

        private boolean stopListener = false;
        
        public void stopListening()
        {
            stopListener = true;
        }
        
        @Override
        public void run() {
            while (!stopListener) {
                try {
                    String msg = (String) sInput.readObject();
                    System.out.println("CLIENT " + username + " " + msg);
                    msgAct(msg);

                } catch (IOException e) {
                    System.out.println("Server has close the connection: " + e);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        
        

    }
    
    

}
