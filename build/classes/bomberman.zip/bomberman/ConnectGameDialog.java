/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bomberman;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 *
 * @author fanda
 */
public class ConnectGameDialog extends Stage{

    public ConnectGameDialog(Stage primaryStage, Client client) throws UnknownHostException {
        this.initOwner(primaryStage);
        this.initModality(Modality.WINDOW_MODAL);
        this.setTitle("Vytvořit hru");

        TextField playerName = new TextField();

        TextArea area = new TextArea();

        Button create = new Button("Vytvořit hru");
        create.setOnAction(e -> {
            String username = playerName.getText();
            if (username.length() != 0) {
                playerName.setEditable(false);
                create.setDisable(true);
                client.setName(username);
                client.start();
                //client.log(are);
            } else {
                System.out.println("Neplatné jméno!");
            }
        });

        GridPane root = new GridPane();
        root.setAlignment(Pos.TOP_CENTER);
        root.setHgap(20);
        root.setVgap(10);

        Text lbCaption = new Text("IP: " + InetAddress.getLocalHost().getHostAddress());
        lbCaption.setFont(Font.font(20));

        root.add(lbCaption, 0, 0, 2, 1);
        root.addRow(1, new Text("Jméno hráče: "), playerName);
        root.addRow(2, create);
        root.addRow(3, area);

        this.setScene(new Scene(root, 400, 300));
    }
    
}
