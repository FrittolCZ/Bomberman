/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bomberman;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 *
 * @author fanda
 */
class CreateGameDialog extends Stage {
    
    private final TextField nameField, msgField;
    private final Text lbCaption;
    private final Button createBtn, startBtn, sendBtn;
    private final TextArea chatArea;
    private final ListView connectedPlayers;
    private final Client client;
    
    public CreateGameDialog(Stage primaryStage, Client client) throws UnknownHostException, IOException {
        this.initOwner(primaryStage);
        this.initModality(Modality.WINDOW_MODAL);
        this.setTitle("Vytvořit hru");
        this.client = client;
        
        lbCaption = new Text("Založit hru");
        lbCaption.setFont(Font.font(20));
        
        nameField = new TextField();
        
        connectedPlayers = new ListView();
        
        chatArea = new TextArea();
        chatArea.setEditable(false);
        
        msgField = new TextField();
        msgField.setDisable(true);
        msgField.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER) {
                sendChatMessage();
            }
        });
        
        createBtn = new Button("Vyvořit hru");
        createBtn.setOnAction(e -> {
            String username = nameField.getText();
            if (username.length() != 0) {
                nameField.setEditable(false); // vypne editaci jména
                createBtn.setDisable(true); // deaktivuje tlačítko spuštení serveru
                Thread serverThread = new Thread(new Server(username)); // vytvoří nové vlákno server 
                serverThread.start(); // spustí vlákno
                msgField.setDisable(false);
                client.setName(username); // nastaví clientovi jméno
                client.setServerOwner();
                client.start(); // spustí clienta 
                client.log(chatArea, connectedPlayers); // začne zapisovat přijaté zprávy do chatu
            } else {
                System.out.println("Neplatné jméno!");
            }
        });
        
        startBtn = new Button("Spustit hru");
        startBtn.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
        sendBtn = new Button("Odeslat");
        sendBtn.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
        sendBtn.setOnAction(e -> {
            sendChatMessage();
        });
        
        GridPane.setHalignment(startBtn, HPos.RIGHT);
        GridPane.setHgrow(msgField, Priority.ALWAYS);
        
        GridPane root = new GridPane();
        
        GridPane msgPane = new GridPane();
        
        root.setAlignment(Pos.TOP_CENTER);
        root.setHgap(20);
        root.setVgap(10);
        root.setPadding(new Insets(10, 10, 10, 10));
        
        root.add(lbCaption, 0, 0, 2, 1);
        root.addRow(1, new Text("Jméno hráče"), nameField);
        root.addRow(2, createBtn, startBtn);
        
        root.addRow(3, new Text("Chat:"), new Text("Připojení hráči:"));
        
        root.addRow(4, chatArea, connectedPlayers);
        
        msgPane.addRow(0, new Text("Zpráva: "), msgField);
        
        root.addRow(5, msgPane, sendBtn);
        
        this.setScene(new Scene(root, 600, 400));
    }
    
    private void sendChatMessage() {
        String msgText = msgField.getText();
        if (msgText.length() != 0) {
            client.sendChatMsg(msgText);
        }
        msgField.setText("");
    }
    
}
