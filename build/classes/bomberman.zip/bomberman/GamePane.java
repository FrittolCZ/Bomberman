/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bomberman;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

/**
 *
 * @author fanda
 */
public class GamePane extends Pane{
    
    private int unitsize;
    private MyGameState game;
    
    public GamePane(int unitsize, MyGameState game)
    {
        this.game = game;
        this.unitsize = unitsize;
        super.setWidth(unitsize * MyGameState.WIDTH * MyGameState.SIZE);
        super.setHeight(unitsize * MyGameState.HEIGHT * MyGameState.SIZE);
        createGameMap();
        initPlayer();
    }
    
    private void createGameMap() {
        for (int x = 0; x < MyGameState.WIDTH; x++) {
            for (int y = 0; y < MyGameState.HEIGHT; y++) {
                if (x / MyGameState.SIZE == 0 || y / MyGameState.SIZE == 0
                        || x / MyGameState.SIZE == (MyGameState.WIDTH - 1) / MyGameState.SIZE
                        || y / MyGameState.SIZE == (MyGameState.HEIGHT - 1) / MyGameState.SIZE
                        || ((x / MyGameState.SIZE) % 2 == 0 && (y / MyGameState.SIZE) % 2 == 0)) {
                    Brick brick = new Brick(x, y);
                    addBrickToPane(brick, Color.GREY);
                    game.addSolidBrick(brick);

                } else {
                    Brick brick = new Brick(x, y);
                    addBrickToPane(brick, Color.ORANGE);
                    game.addDestructibleBrick(brick);
                }
            }
        }
    }

    private void addBrickToPane(Brick brick, Color color) {
        Rectangle rect = new Rectangle(brick.getX() * unitsize, brick.getY() * unitsize, unitsize, unitsize);
        rect.visibleProperty().bind(brick.activeProperty());
        rect.setFill(color);
        this.getChildren().add(rect);
    }
    
    public void drawBomb(Bomb bomb) {
        for (Brick b : bomb.getParticles()) {
            Rectangle rect = new Rectangle(b.getX() * unitsize, b.getY() * unitsize, unitsize, unitsize);
            rect.visibleProperty().bind(b.activeProperty());
            rect.setFill(Color.BLACK);
            this.getChildren().add(rect);
        }
        for (Brick flame : bomb.getFlames()) {
            Rectangle rect = new Rectangle(flame.getX() * unitsize, flame.getY() * unitsize, unitsize, unitsize);
            rect.visibleProperty().bind(flame.activeProperty());
            rect.setFill(Color.RED);
            this.getChildren().add(rect);
        }
    }

    private void initPlayer() {
        Player player = game.initPlayer();

        for (Brick b : player.getParticles()) {
            Rectangle rect = new Rectangle(unitsize, unitsize);
            rect.xProperty().bind(b.xProperty().multiply(unitsize));
            rect.yProperty().bind(b.yProperty().multiply(unitsize));
            rect.setFill(Color.YELLOW);
            this.getChildren().add(rect);
        }
    }
    
}
