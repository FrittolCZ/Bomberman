/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bomberman;

import java.awt.Point;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author fanda
 */
class MyGameState {

    public static final int SIZE = 4;

    public static final int WIDTH = 60;
    public static final int HEIGHT = 60;

    //nerozbitelné kostky
    private final ArrayList<Brick> solidBricks = new ArrayList<>();

    //rozbitelné kostky
    private final ArrayList<Brick> destructibleBricks = new ArrayList<>();

    private Player player;

    // hráči ve hře
    //private final ArrayList<Player> players = new ArrayList<>();
    private final HashMap<String, Player> players = new HashMap<>();

    // volné startovní pozice
    private final ArrayList<Point> startPositions = new ArrayList<>();

    //bomby na hrací plošes
    private final ArrayList<Bomb> bombs = new ArrayList<>();

    public MyGameState() {
        initStartPositions();
    }

    public ArrayList<Brick> getSolidBricks() {
        return solidBricks;
    }

    public ArrayList<Brick> getDestructibleBricks() {
        return destructibleBricks;
    }

    public HashMap<String,Player> getPlayers() {
        return players;
    }

    public ArrayList<Bomb> getBombs() {
        return bombs;
    }

    public void update(float delta) {
        for (int i = 0; i < bombs.size(); i++) {
            Bomb bomb = bombs.get(i);
            if (!bomb.isDead()) {
                bomb.update(delta);
            } else {
                destructibleBricks.forEach((brick) -> {
                    if (bomb.getFlames().contains(brick)) {
                        brick.deactive();
                    }
                });
                // zkontroluj zda byl zasažen hráč 
                bombs.remove(bomb);
                i--;
                bomb.getFlames().forEach((flame) -> {
                    flame.deactive();
                });
            }
        }
    }

    public Player initPlayer() {
        Point start = startPositions.get(0);
        startPositions.remove(start);
        player = new Player((int) start.getX() * SIZE, (int) start.getY() * SIZE);
        destructibleBricks.forEach((b) -> {
            player.getParticles().stream().filter((part) -> (part.getX() == b.getX() && part.getY() == b.getY()
                    || part.getX() == b.getX() && b.getY() == part.getY() + SIZE
                    || part.getX() + SIZE == b.getX() && b.getY() == part.getY())).forEachOrdered((_item) -> {
                b.deactive();
            });
        });
        return this.player;
    }

    private void initStartPositions() {
        startPositions.add(new Point(1, 1));
        startPositions.add(new Point(WIDTH - 2, 1));
        startPositions.add(new Point(1, HEIGHT - 2));
        startPositions.add(new Point(WIDTH - 2, HEIGHT - 2));

    }

    public void moveLeft() {
        if (!checkCollision(-1, 0)) {
            player.move(-1, 0);
        }
    }

    public void moveRight() {
        if (!checkCollision(1, 0)) {
            player.move(1, 0);
        }
    }

    public void moveDown() {
        if (!checkCollision(0, 1)) {
            player.move(0, 1);
        }
    }

    public void moveUp() {
        if (!checkCollision(0, -1)) {
            player.move(0, -1);
        }
    }

    public Bomb placeBomb() {
        Bomb bomb = new Bomb(player.getParticles());
        createFlames(bomb);
        bombs.add(bomb);
        return bomb;
    }

    private boolean checkCollision(int x, int y) {
        for (Brick part : player.getParticles()) {
            if (solidBricks.stream().anyMatch((b) -> (part.getX() + x == b.getX() && part.getY() + y == b.getY() && b.isActive()))) {
                return true;
            }
            if (destructibleBricks.stream().anyMatch((b) -> (part.getX() + x == b.getX() && part.getY() + y == b.getY() && b.isActive()))) {
                return true;
            }
        }
        return false;
    }

    private void createFlames(Bomb bomb) {
        boolean breakFlame = false;

        ArrayList<Brick> flames = new ArrayList<>();

        Point[] directions = {new Point(0, 1), new Point(0, -1), new Point(1, 0), new Point(-1, 0)}; // směry šíření plamene

        Brick flame;

        for (Point p : directions) // projdu všechny směry 
        {
            for (int i = 1; i <= player.getBombFlame(); i++) {
                for (Brick part : bomb.getParticles()) {
                    flame = new Brick(part.getX() + ((int) p.getX() * i) * SIZE, part.getY() + ((int) p.getY() * i) * SIZE);
                    flame.deactive();
                    if (!solidBricks.contains(flame)) {
                        for (Brick b : destructibleBricks) {
                            if (b.equals(flame)) {
                                breakFlame = true;
                            }
                        }
                        flames.add(flame);
                    } else {
                        breakFlame = true;
                        break;
                    }
                }

                // pokud jsem v tomto směru narazil na překážku již v tomto směru nepřidávám
                if (breakFlame) {
                    break;
                }
            }
        }
        for (Brick part : bomb.getParticles()) {
            flame = new Brick(part.getX(), part.getY());
            flame.deactive();
            flames.add(flame);
        }

        bomb.setFlames(flames);
    }

    private boolean checkSolids(Bomb bomb, int x, int y) {
        return true;
    }

    public void addSolidBrick(Brick brick) {
        solidBricks.add(brick);
    }

    public void addDestructibleBrick(Brick brick) {
        destructibleBricks.add(brick);
    }

    boolean end() {
        return false;
    }

    void movePlayer(String player, String dir) {
        //Player pl = players.
    }

    void plantBomb(String player) {
        
    }
}
