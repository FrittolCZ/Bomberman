/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bomberman;

import java.util.ArrayList;

/**
 *
 * @author fanda
 */
public class Player {

    private int speed = 1;
    private int lives = 3;
    private int bombMax = 1;
    private int bombFlame = 2;
    private int bombs = 0;

    private ArrayList<Brick> particles;

    public Player(int x, int y) {
        initParts(x, y);
    }

    private void initParts(int origX, int origY) {
        particles = new ArrayList<>();
        for (int x = 0; x < MyGameState.SIZE; x++) {
            for (int y = 0; y < MyGameState.SIZE; y++) {
                particles.add(new Brick(origX + x, origY + y));
            }
        }
    }

    public ArrayList<Brick> getParticles() {
        return particles;
    }

    public float getSpeed() {
        return speed;
    }

    public int getLives() {
        return lives;
    }

    public int getBombMax() {
        return bombMax;
    }

    public int getBombFlame() {
        return bombFlame;
    }

    /**
     * Zvýší rychlost hráče
     *
     * @param speed
     */
    public void addSpeed(float speed) {
        this.speed += speed;
    }

    /**
     * Zvýší či zmenší počet životů
     *
     * @param lives
     */
    public void addLives(int lives) {
        this.lives += lives;
    }

    /**
     * Navýší maximální počet bomb které hráč může umýstit
     *
     * @param bombMax
     */
    public void addBombMax(int bombMax) {
        this.bombMax += bombMax;
    }

    /**
     * Zvětší dosah plamene hráčových bomb
     *
     * @param bombFlame
     */
    public void addBombFlame(int bombFlame) {
        this.bombFlame += bombFlame;
    }

    /**
     * Zvýší počet bomb které hráč umýstil a ještě nevybuchly
     *
     * @return Vrací true pokud bomba byla vytvořena
     */
    public boolean placeBomb() {
        if (bombs < bombMax) {
            bombs++;
            return true;
        }
        return false;
    }

    void move(int x, int y) {
        for (Brick b : particles) {
            b.setX(b.getX() + x);
            b.setY(b.getY() + y);
        }
    }

}
