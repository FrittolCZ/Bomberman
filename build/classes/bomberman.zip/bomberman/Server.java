/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bomberman;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.util.Duration;

/**
 *
 * @author fanda
 */
public class Server implements Runnable {

    private String owner;
    private final int maxPlayers = 4; // maximální počet klientů kteří se mohou připojit
    private ServerSocket serverSocket;
    private final int port = 4242;
    private final ArrayList<ClientThread> clients; // seznam všech klientů
    private boolean stopServer = false; // pokud true zastav server

    // interval v kterém probíhají aktualizace hry které jsou dalé rozesílány klientům
    private static final int DELAY = 100;
    // nová hrací plocha
    private final MyGameState game = new MyGameState();
    private Timeline timeline;

    public Server(String owner) {

        this.owner = owner;
        timeline = new Timeline();
        KeyFrame updates = new KeyFrame(Duration.millis(DELAY), e -> {
            if (!game.end()) {
                game.update(DELAY);
            }
        }
        );
        timeline.getKeyFrames().add(updates);
        timeline.setCycleCount(Animation.INDEFINITE);
        clients = new ArrayList<>();
    }

    public void startGame() {
        if (clients.size() > 1) {
            // umísti hráče na hrací plochu
            timeline.play();
        } else {
            System.out.println("Server: Nedostatečný počet hráčů");
        }
    }

    // spustí server
    public void start() throws ClassNotFoundException {
        // Vytvoř socket a čekej na žádosti o připojení 
        try {
            serverSocket = new ServerSocket(port);

            // čekej dokud klienti 
            while (!stopServer) {
                // Pokud je dosaženo maxima hráčů server již další nepřijímá 
                if (clients.size() < maxPlayers) {
                    System.out.println("Server: Čekám na hráče");
                    Socket socket = serverSocket.accept(); // přijmi připojení
                    ClientThread t = new ClientThread(socket);  // vytvoř nové vlákno klienta
                    clients.add(t);
                    t.start();
                }
            }
            // ukončení server
            try {
                serverSocket.close();
                // zavři streamy všech klientů
                for (int i = 0; i < clients.size(); ++i) {
                    ClientThread tc = clients.get(i);
                    tc.close();
                }
            } catch (IOException e) {
                System.out.println("Server: Chyba při zavírání serveru a klientů: " + e);
            }
        } catch (IOException e) {
            System.out.println("Server: Chyba při vytváření socketu: " + e);
        }
    }

    private String getClientsNames() {
        StringBuilder names = new StringBuilder();
        names.append("CONNECTED: ");
        clients.forEach((client) -> {
            names.append(client.getUsername()).append(" ");
        });
        return names.toString();
    }

    protected void stop() {
        stopServer = true;
    }

    synchronized void remove(String username) {
        // Procházej clienty dokud nenajdeš toho jeho jmeéno je username
        for (int i = 0; i < clients.size(); ++i) {
            ClientThread ct = clients.get(i);
            if (ct.getUsername().equals(username)) {
                clients.remove(i);
                return;
            }
        }
    }

    /**
     * Vyšle zprávu všem klientům
     *
     * @param message - zpráva pro klienty
     */
    private synchronized void broadcast(String msg) {
        //Projde všechny klienty a zašel jim zprávu
        clients.forEach((ct) -> {
            try {
                ct.writeMsg(msg);
            } catch (IOException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }

    @Override
    public void run() {
        try {
            this.start();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private boolean validMsg(String msg) {
        ArrayList<String> directions = new ArrayList<>();
        directions.add("UP");
        directions.add("DOWN");
        directions.add("LEFT");
        directions.add("RIGHT");

        String[] parts = msg.split(" ");
        if (getClientsNames().contains(parts[1])) {
            if (parts[0].equals("MOVE")) {
                if (parts.length == 3 && directions.contains(parts[3])) {
                    return true;
                }
            } else if (parts[0].equals("PLANT") && parts.length == 2) {
                return true;
            } else if (parts[0].equals("START") && parts.length == 1) {
                return true;
            } else if (parts[0].equals("MSG")) {
                return true;
            } else if (parts[0].equals("STOP") && parts.length == 2) {
                return true;
            }
        }
        return false;
    }

    private void updateGame(String msg) {
        String[] parts = msg.split(" ");
        switch (parts[0]) {
            case "MOVE":
                // pohni s hráčem parts[1] směrem parts[2]
                game.movePlayer(parts[1], parts[2]);
                break;
            case "PLANT":
                // vytvoř bombu pod hráčem parts[1]
                game.plantBomb(parts[1]);
                break;
            case "START":
                startGame();
                broadcast("GAMESTARTED");
                break;
            case "MSG":
                broadcast(msg);
                break;
            case "STOP":
                if (parts[1].equals(owner)) {
                    stop();
                }
                break;
            default:
                break;

        }
    }

    class ClientThread extends Thread {
        // the socket where to listen/talk

        private Socket socket;
        private ObjectInputStream sInput;
        private ObjectOutputStream sOutput;
        private String username;
        private boolean keepGoing = true;

        // Konstruktor vlákna hráče
        ClientThread(Socket socket) throws ClassNotFoundException {
            this.socket = socket;
            System.out.println("Vytvářím Input/Output Streams");
            try {
                sOutput = new ObjectOutputStream(socket.getOutputStream());
                sInput = new ObjectInputStream(socket.getInputStream());
                // Přečte ze vstupu uživatelské jméno
                System.out.println("Server: čtu jméno klienta");
                username = (String) sInput.readObject();
                System.out.println("Server: " + username);
            } catch (IOException e) {
                System.out.println("Chyba při vytváření Input/output Streams: " + e);
            }
        }

        public String getUsername() {
            return username;
        }

        @Override
        public void run() {
            // pošle všem hráčům zprávu o nově připojeném hráči
            broadcast("PLAYER_CONNECTED " + username);
            // čte zprávy dokud se hráč neodhlasí
            while (keepGoing) {
                try {
                    //Přečtu zprávu od klienta
                    String msg = (String) sInput.readObject();
                    System.out.println("SERVER: " + msg);
                    if (validMsg(msg)) {
                        updateGame(msg);
                    }
                } catch (IOException ex) {
                    Logger.getLogger(ClientThread.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
            close();
        }

        // try to close everything
        public void close() {
            // try to close the connection
            try {
                if (sOutput != null) {
                    sOutput.close();
                }
            } catch (IOException e) {
            }
            try {
                if (sInput != null) {
                    sInput.close();
                }
            } catch (IOException e) {
            }
            try {
                if (socket != null) {
                    socket.close();
                }
            } catch (IOException e) {
            }
            keepGoing = false;
        }

        /*
     * Pošli zprávu klientovi
         */
        public void writeMsg(String msg) throws IOException {
            if (!socket.isConnected()) {
                close();
            }
            sOutput.writeObject(msg);
        }
    }
}
